# AURA Store

Official online store for AURA smartphones. Products, images and the admin login live in Supabase; the website is plain static files (Preact + ES modules, no build step), so it can be hosted anywhere static files can be served.

## 1. Set up Supabase (about 10 minutes)

1. Create a project at https://supabase.com.
2. **SQL Editor** → paste the whole of `supabase/schema.sql` → Run. This creates the tables, Row Level Security policies and the `product-images` storage bucket.
3. **Authentication → Users → Add user** → create your admin account (email + a strong password).
4. **Authentication → Sign In / Providers → Email** → turn **off** "Allow new users to sign up", so nobody else can create accounts.
5. Make your account the administrator. In the SQL Editor run (with your email):
   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'you@example.com';
   ```
6. **Project Settings → API** → copy the **Project URL** and the **anon public** key into `js/config.js`.
   Never use the `service_role` key anywhere in this project.

## 2. Run it

Serve the folder with any static server, for example:

```
cd aura-store
python3 -m http.server 8080
```

Open http://localhost:8080. For production, upload the folder to Netlify, Vercel, Cloudflare Pages, GitHub Pages or any web host. Routing uses `#/` URLs, so no server rewrite rules are needed.

## 3. Add your first phone

Open `/#/admin`, sign in, choose **Add smartphone**, fill in the details, upload your own renders, and press **Publish**. It appears on the website immediately. Use **Save as draft** to keep it hidden. No code changes are ever needed to add a phone.

## How access is protected

- Visitors use the public anon key and can only `select` **published** products (RLS policy). They cannot insert, update or delete anything.
- Admin access is an allowlist: the `admins` table. Writes to products, images, subscribers and the activity log require `public.is_admin()` to be true, enforced by the database and storage, not by the JavaScript.
- The `admins` table has no write policies, so it can only be changed from the Supabase dashboard.
- No password or secret is in the frontend code. Signing in uses Supabase Auth.
- Product images: anyone can view them, only the admin can upload, replace or delete.

## What to review before launch

- `js/config.js`: add your support email, phone, hours and address (anything left empty is hidden), and set the warranty length. The warranty wording on the Support page (`js/pages/support.js`) is generic. Check it against your real warranty terms.
- Payments: no payment provider is configured, so the bag cannot place orders. The bag clearly says so. Adding checkout means integrating a provider (for example Stripe), which is not included.
- Prices in the bag are re-checked against the live catalogue every time it is opened.
- Currency is set in `js/config.js` (`USD` by default).

## Structure

```
index.html              entry page
css/styles.css          design tokens and all styles
js/config.js            public settings
js/lib.js               Supabase client, data access, cart/compare stores, helpers
js/ui.js                shared components (cards, states, newsletter)
js/app.js               router, header, footer
js/pages/               home, catalog, product, compare, cart, support, admin
supabase/schema.sql     tables, RLS, storage policies
```

The site loads Preact, htm and supabase-js from esm.sh at runtime, so visitors need internet access. To self-host them, replace those import URLs in `js/lib.js` with bundled copies.

// Public configuration. Only put PUBLIC values here.
// The Supabase "anon" key is designed to be public: what visitors can do is
// controlled by the Row Level Security policies in supabase/schema.sql.
// NEVER put the service_role key (or any password) in this file.

export const CONFIG = {
  supabaseUrl: 'YOUR_SUPABASE_URL',
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_KEY',

  currency: 'USD',
  locale: 'en-US',

  // Shown on the Support page. Leave a value empty to hide it.
  support: {
    email: '',
    phone: '',
    hours: '',
    address: '',
  },

  // Warranty length shown on the Support page. Review the wording there
  // against your real warranty terms before launch.
  warrantyMonths: 12,
};

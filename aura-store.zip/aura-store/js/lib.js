import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import {
  html, render, useState, useEffect, useMemo, useRef,
} from 'https://esm.sh/htm/preact/standalone';
import { CONFIG } from './config.js';

export { html, render, useState, useEffect, useMemo, useRef, CONFIG };

/* ------------------------------------------------------------------ client */

export const isConfigured =
  !!CONFIG.supabaseUrl &&
  !!CONFIG.supabaseAnonKey &&
  !CONFIG.supabaseUrl.startsWith('YOUR_') &&
  !CONFIG.supabaseAnonKey.startsWith('YOUR_');

export const supabase = isConfigured
  ? createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey)
  : null;

export const BUCKET = 'product-images';

/* ----------------------------------------------------------------- helpers */

export function errMsg(e) {
  if (!e) return 'Something went wrong.';
  if (typeof e === 'string') return e;
  return e.message || 'Something went wrong.';
}

export function money(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return '';
  return new Intl.NumberFormat(CONFIG.locale, {
    style: 'currency',
    currency: CONFIG.currency,
    maximumFractionDigits: v % 1 === 0 ? 0 : 2,
  }).format(v);
}

export function slugify(s) {
  return String(s || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function mainImage(p) {
  return p && Array.isArray(p.images) && p.images[0] ? p.images[0].url : null;
}

export function startingPrice(p) {
  const prices = (p.configurations || [])
    .map((c) => (c.price === '' || c.price == null ? null : Number(c.price)))
    .filter((n) => Number.isFinite(n));
  const base = Number(p.base_price);
  return prices.length ? Math.min(base, ...prices) : base;
}

export function configPrice(p, cfg) {
  if (cfg && cfg.price !== '' && cfg.price != null && Number.isFinite(Number(cfg.price))) {
    return Number(cfg.price);
  }
  return Number(p.base_price);
}

export const SPEC_FIELDS = [
  ['display', 'Display'],
  ['processor', 'Processor'],
  ['main_camera', 'Main camera'],
  ['front_camera', 'Front camera'],
  ['battery', 'Battery'],
  ['charging', 'Charging'],
  ['os', 'Operating system'],
];

// Only specifications the administrator has actually entered.
export function specRows(p) {
  const rows = [];
  for (const [key, label] of SPEC_FIELDS) {
    const v = (p[key] || '').trim();
    if (v) rows.push([label, v]);
  }
  for (const e of p.extra_specs || []) {
    if (e && (e.label || '').trim() && (e.value || '').trim()) rows.push([e.label.trim(), e.value.trim()]);
  }
  return rows;
}

export function configLabel(cfg) {
  return [cfg.ram, cfg.storage].filter(Boolean).join(' + ');
}

/* -------------------------------------------------------------- data access */

export async function fetchPublished() {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('status', 'published')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function fetchBySlug(slug) {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('slug', slug)
    .eq('status', 'published')
    .maybeSingle();
  if (error) throw error;
  return data;
}

export async function subscribe(email) {
  const { error } = await supabase.from('subscribers').insert({ email: email.trim() });
  if (error) {
    if (error.code === '23505') return 'already';
    throw error;
  }
  return 'ok';
}

/* ------------------------------------------------------------------- hooks */

export function useAsync(fn, deps = []) {
  const [state, setState] = useState({ loading: true, data: null, error: null });
  const [n, setN] = useState(0);
  useEffect(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    fn().then(
      (data) => alive && setState({ loading: false, data, error: null }),
      (error) => alive && setState({ loading: false, data: null, error }),
    );
    return () => { alive = false; };
    // eslint-disable-next-line
  }, [...deps, n]);
  return { ...state, reload: () => setN((x) => x + 1) };
}

export function useRoute() {
  const read = () => {
    const raw = (window.location.hash || '#/').replace(/^#/, '') || '/';
    const [path, qs] = raw.split('?');
    return { path: path || '/', query: Object.fromEntries(new URLSearchParams(qs || '')) };
  };
  const [route, setRoute] = useState(read);
  useEffect(() => {
    const onChange = () => { setRoute(read()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return route;
}

export function go(path) {
  window.location.hash = '#' + path;
}

export function setTitle(t) {
  document.title = t ? `${t} — AURA Store` : 'AURA Store';
}

/* ------------------------------------------------- small persisted stores */

function persisted(key, fallback) {
  let value;
  try { value = JSON.parse(localStorage.getItem(key)); } catch { value = null; }
  if (!Array.isArray(value)) value = fallback;
  const subs = new Set();
  return {
    get: () => value,
    set(next) {
      value = next;
      try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable */ }
      subs.forEach((f) => f());
    },
    use() {
      const [, tick] = useState(0);
      useEffect(() => {
        const f = () => tick((x) => x + 1);
        subs.add(f);
        return () => subs.delete(f);
      }, []);
      return value;
    },
  };
}

export const cartStore = persisted('aura.cart', []);
export const compareStore = persisted('aura.compare', []);
export const COMPARE_MAX = 4;

export function cartKey(i) {
  return [i.id, i.color, i.ram, i.storage].join('|');
}

export function addToCart(item) {
  const cart = cartStore.get();
  const key = cartKey(item);
  const existing = cart.find((i) => cartKey(i) === key);
  if (existing) {
    cartStore.set(cart.map((i) => (cartKey(i) === key ? { ...i, qty: Math.min(i.qty + 1, 10) } : i)));
  } else {
    cartStore.set([...cart, { ...item, qty: 1 }]);
  }
}

export function setQty(key, qty) {
  const q = Math.max(1, Math.min(10, qty));
  cartStore.set(cartStore.get().map((i) => (cartKey(i) === key ? { ...i, qty: q } : i)));
}

export function removeFromCart(key) {
  cartStore.set(cartStore.get().filter((i) => cartKey(i) !== key));
}

export function toggleCompare(id) {
  const list = compareStore.get();
  if (list.includes(id)) compareStore.set(list.filter((x) => x !== id));
  else if (list.length < COMPARE_MAX) compareStore.set([...list, id]);
}

/* ------------------------------------------------------------- admin auth */

export function useAdmin() {
  const [state, setState] = useState({ status: 'loading', user: null });
  useEffect(() => {
    let alive = true;
    async function check(session) {
      if (!session) { alive && setState({ status: 'out', user: null }); return; }
      const { data, error } = await supabase
        .from('admins').select('user_id').eq('user_id', session.user.id).maybeSingle();
      if (!alive) return;
      if (error) setState({ status: 'error', user: session.user, error });
      else setState({ status: data ? 'ok' : 'denied', user: session.user });
    }
    supabase.auth.getSession().then(({ data }) => check(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      // Defer: calling supabase inside this callback can deadlock.
      setTimeout(() => check(session), 0);
    });
    return () => { alive = false; sub.subscription.unsubscribe(); };
  }, []);
  return state;
}

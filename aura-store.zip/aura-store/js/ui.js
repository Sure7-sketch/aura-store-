import {
  html, useState, compareStore, COMPARE_MAX, toggleCompare,
  mainImage, money, startingPrice, subscribe, errMsg,
} from './lib.js';

/* Neutral device illustration, shown only when no render has been uploaded. */
export function PhoneArt({ className = '' }) {
  return html`
    <svg class=${'phone-art ' + className} viewBox="0 0 280 560" role="img" aria-label="AURA smartphone">
      <rect x="20" y="10" width="240" height="540" rx="40" fill="#E9E5F3" />
      <rect x="26" y="16" width="228" height="528" rx="34" fill="#F6F4FA" />
      <rect x="48" y="40" width="96" height="104" rx="24" fill="#E3DEF0" />
      <circle cx="78" cy="70" r="17" fill="#CFC8E3" />
      <circle cx="78" cy="70" r="9" fill="#A79AD0" />
      <circle cx="116" cy="108" r="17" fill="#CFC8E3" />
      <circle cx="116" cy="108" r="9" fill="#A79AD0" />
      <circle cx="78" cy="118" r="7" fill="#CFC8E3" />
      <text x="140" y="330" text-anchor="middle" font-family="Inter, sans-serif" font-size="30" font-weight="600" letter-spacing="9" fill="#7545D8" opacity="0.85">AURA</text>
    </svg>`;
}

export function Loading({ label = 'Loading' }) {
  return html`<div class="state" role="status"><span class="spinner" aria-hidden="true"></span><span>${label}…</span></div>`;
}

export function ErrorBox({ error, onRetry, title = 'We couldn’t load this' }) {
  return html`
    <div class="state state-error" role="alert">
      <strong>${title}</strong>
      <span>${errMsg(error)}</span>
      ${onRetry && html`<button class="btn btn-ghost btn-sm" onClick=${onRetry}>Try again</button>`}
    </div>`;
}

export function Empty({ title, children }) {
  return html`<div class="state"><strong>${title}</strong>${children && html`<span>${children}</span>`}</div>`;
}

export function ProductImage({ product, className = '' }) {
  const src = mainImage(product);
  return src
    ? html`<img class=${className} src=${src} alt=${product.name} loading="lazy" />`
    : html`<${PhoneArt} className=${className} />`;
}

export function ProductCard({ p }) {
  const selected = compareStore.use();
  const inCompare = selected.includes(p.id);
  const full = !inCompare && selected.length >= COMPARE_MAX;
  const href = `#/phones/${p.slug}`;
  return html`
    <article class="card">
      <a class="card-media" href=${href} aria-label=${p.name}>
        <${ProductImage} product=${p} />
      </a>
      <div class="card-body">
        ${p.category && html`<p class="eyebrow">${p.category}</p>`}
        <h3 class="card-title"><a href=${href}>${p.name}</a></h3>
        ${p.tagline && html`<p class="muted card-text">${p.tagline}</p>`}
        <p class="price">From ${money(startingPrice(p))}</p>
        <div class="card-actions">
          <a class="btn btn-sm" href=${href}>View details</a>
          <button
            class=${'btn btn-sm btn-ghost' + (inCompare ? ' is-on' : '')}
            onClick=${() => toggleCompare(p.id)}
            disabled=${full}
            aria-pressed=${inCompare}
            title=${full ? `You can compare up to ${COMPARE_MAX} phones` : ''}
          >${inCompare ? 'Remove from compare' : 'Compare'}</button>
        </div>
      </div>
    </article>`;
}

export function Newsletter() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState({ kind: 'idle', text: '' });

  async function onSubmit(e) {
    e.preventDefault();
    setStatus({ kind: 'busy', text: '' });
    try {
      const r = await subscribe(email);
      setStatus(r === 'already'
        ? { kind: 'ok', text: 'This address is already subscribed.' }
        : { kind: 'ok', text: 'Thank you. You are subscribed.' });
      if (r === 'ok') setEmail('');
    } catch (err) {
      setStatus({ kind: 'error', text: errMsg(err) });
    }
  }

  return html`
    <section class="section section-soft newsletter" aria-labelledby="nl-h">
      <div class="container narrow center">
        <h2 id="nl-h" class="h2">Stay in the loop</h2>
        <p class="lead muted">News about new AURA phones, straight to your inbox.</p>
        <form class="inline-form" onSubmit=${onSubmit} noValidate=${false}>
          <label class="sr-only" for="nl-email">Email address</label>
          <input id="nl-email" class="input" type="email" required placeholder="Email address"
            autocomplete="email" value=${email} onInput=${(e) => setEmail(e.target.value)} />
          <button class="btn" type="submit" disabled=${status.kind === 'busy'}>
            ${status.kind === 'busy' ? 'Subscribing…' : 'Subscribe'}
          </button>
        </form>
        <p class=${'form-note ' + (status.kind === 'error' ? 'is-error' : '')} role="status">${status.text}</p>
      </div>
    </section>`;
}

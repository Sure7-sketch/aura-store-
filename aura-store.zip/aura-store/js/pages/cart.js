import {
  html, useEffect, useAsync, fetchPublished, setTitle, cartStore, cartKey, setQty,
  removeFromCart, money, configPrice, mainImage,
} from '../lib.js';
import { PhoneArt, Loading, ErrorBox } from '../ui.js';

export function Cart() {
  useEffect(() => setTitle('Shopping bag'), []);
  const items = cartStore.use();
  const { data, loading, error, reload } = useAsync(fetchPublished);

  if (items.length === 0) {
    return html`
      <div class="container">
        <div class="page-head"><h1 class="h1" style="font-size:clamp(38px,5vw,60px)">Your bag</h1></div>
        <div class="state" style="padding-bottom:140px">
          <strong>Your bag is empty</strong>
          <a class="btn" href="#/phones" style="margin-top:12px">Explore phones</a>
        </div>
      </div>`;
  }

  if (loading) return html`<div class="container"><${Loading} label="Checking prices" /></div>`;
  if (error) return html`<div class="container"><${ErrorBox} error=${error} onRetry=${reload} title="We couldn’t check current prices" /></div>`;

  // Re-price every line against the live catalogue so totals are never stale.
  const lines = items.map((item) => {
    const product = (data || []).find((p) => p.id === item.id);
    if (!product) return { item, product: null, price: null };
    const cfg = (product.configurations || []).find(
      (c) => (c.ram || '') === item.ram && (c.storage || '') === item.storage,
    );
    return { item, product, price: configPrice(product, cfg), cfgMissing: !!(item.ram || item.storage) && !cfg };
  });
  const available = lines.filter((l) => l.product);
  const total = available.reduce((s, l) => s + l.price * l.item.qty, 0);
  const units = available.reduce((s, l) => s + l.item.qty, 0);

  return html`
    <div class="container">
      <div class="page-head"><h1 class="h1" style="font-size:clamp(38px,5vw,60px)">Your bag</h1></div>
      <div class="cart">
        <div>
          ${lines.map(({ item, product, price }) => {
            const key = cartKey(item);
            const image = product ? mainImage(product) : item.image;
            return html`
              <div class="line" key=${key}>
                <div class="line-img">${image ? html`<img src=${image} alt="" />` : html`<${PhoneArt} />`}</div>
                <div>
                  <h3>${product ? html`<a href=${`#/phones/${product.slug}`}>${item.name}</a>` : item.name}</h3>
                  <p class="meta">${[item.color, item.ram, item.storage].filter(Boolean).join(' · ')}</p>
                  ${!product && html`<p class="unavailable">No longer available. It is not included in the total.</p>`}
                  ${product && html`
                    <div class="qty" role="group" aria-label=${`Quantity for ${item.name}`}>
                      <button aria-label="Decrease quantity" disabled=${item.qty <= 1} onClick=${() => setQty(key, item.qty - 1)}>−</button>
                      <span aria-live="polite">${item.qty}</span>
                      <button aria-label="Increase quantity" disabled=${item.qty >= 10} onClick=${() => setQty(key, item.qty + 1)}>+</button>
                    </div>`}
                </div>
                <div class="line-side">
                  ${product && html`<p class="price">${money(price * item.qty)}</p>`}
                  ${product && item.qty > 1 && html`<p class="muted" style="font-size:13px">${money(price)} each</p>`}
                  <button class="link-btn" onClick=${() => removeFromCart(key)}>Remove</button>
                </div>
              </div>`;
          })}
        </div>

        <aside class="summary" aria-label="Order summary">
          <h2>Summary</h2>
          <div class="row"><span>${units} ${units === 1 ? 'item' : 'items'}</span><span>${money(total)}</span></div>
          <div class="row total"><span>Total</span><span>${money(total)}</span></div>
          <div class="notice">
            <strong>Online checkout isn’t available yet</strong>
            Payments aren’t set up on this store, so orders can’t be placed here. Your bag is saved on this device.
          </div>
        </aside>
      </div>
    </div>`;
}

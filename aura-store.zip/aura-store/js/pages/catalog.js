import {
  html, useState, useEffect, useMemo, useAsync, fetchPublished, startingPrice,
  setTitle, compareStore, go,
} from '../lib.js';
import { ProductCard, Loading, ErrorBox, Empty } from '../ui.js';

const SORTS = {
  newest: 'Newest',
  'price-asc': 'Price: low to high',
  'price-desc': 'Price: high to low',
  name: 'Name',
};

export function Catalog({ query }) {
  useEffect(() => setTitle('Smartphones'), []);
  const { data, loading, error, reload } = useAsync(fetchPublished);
  const [q, setQ] = useState(query.q || '');
  const [cat, setCat] = useState(query.cat || '');
  const [sort, setSort] = useState('newest');
  const selected = compareStore.use();

  // Keep filters in sync when arriving from the search box or lineup links.
  useEffect(() => { setQ(query.q || ''); setCat(query.cat || ''); }, [query.q, query.cat]);

  const list = data || [];
  const categories = useMemo(() => [...new Set(list.map((p) => p.category).filter(Boolean))].sort(), [data]);

  const shown = useMemo(() => {
    const term = q.trim().toLowerCase();
    let out = list.filter((p) =>
      (!cat || p.category === cat) &&
      (!term || [p.name, p.tagline, p.category].join(' ').toLowerCase().includes(term)));
    const by = {
      newest: (a, b) => new Date(b.created_at) - new Date(a.created_at),
      'price-asc': (a, b) => startingPrice(a) - startingPrice(b),
      'price-desc': (a, b) => startingPrice(b) - startingPrice(a),
      name: (a, b) => a.name.localeCompare(b.name),
    }[sort];
    return out.sort(by);
  }, [data, q, cat, sort]);

  const filtered = q.trim() || cat;
  function reset() { setQ(''); setCat(''); setSort('newest'); if (query.q || query.cat) go('/phones'); }

  return html`
    <div class="container">
      <div class="page-head">
        <h1 class="h1" style="font-size:clamp(38px,5vw,60px)">Smartphones</h1>
        <p class="lead muted">Choose the AURA phone that fits the way you use it.</p>
      </div>

      <div class="toolbar">
        <label class="sr-only" for="cat-q">Search</label>
        <input id="cat-q" class="input" type="search" placeholder="Search phones" value=${q}
          onInput=${(e) => setQ(e.target.value)} />
        ${categories.length > 0 && html`
          <label class="sr-only" for="cat-c">Category</label>
          <select id="cat-c" class="select" value=${cat} onChange=${(e) => setCat(e.target.value)}>
            <option value="">All categories</option>
            ${categories.map((c) => html`<option value=${c}>${c}</option>`)}
          </select>`}
        <label class="sr-only" for="cat-s">Sort by</label>
        <select id="cat-s" class="select" value=${sort} onChange=${(e) => setSort(e.target.value)}>
          ${Object.entries(SORTS).map(([v, l]) => html`<option value=${v}>${l}</option>`)}
        </select>
        <span class="spacer"></span>
        ${filtered && html`<button class="btn btn-ghost btn-sm" onClick=${reset}>Clear filters</button>`}
        ${!loading && !error && html`<span class="result-count" role="status">${shown.length} ${shown.length === 1 ? 'phone' : 'phones'}</span>`}
      </div>

      ${loading && html`<${Loading} label="Loading phones" />`}
      ${error && html`<${ErrorBox} error=${error} onRetry=${reload} title="We couldn’t load the phones" />`}
      ${!loading && !error && list.length === 0 && html`<${Empty} title="No phones available yet">New AURA phones are coming soon.<//>`}
      ${!loading && !error && list.length > 0 && shown.length === 0 && html`
        <${Empty} title="No phones match your search">Try a different search or clear the filters.<//>`}
      ${shown.length > 0 && html`<div class="grid" style="padding-bottom:96px">${shown.map((p) => html`<${ProductCard} key=${p.id} p=${p} />`)}</div>`}

      ${selected.length >= 2 && html`
        <div class="compare-bar" style="margin-bottom:32px">
          <span>${selected.length} phones selected</span>
          <a class="btn btn-sm" href="#/compare">Compare now</a>
        </div>`}
    </div>`;
}

import {
  html, useAsync, fetchPublished, setTitle, useEffect, mainImage, specRows,
} from '../lib.js';
import {
  ProductCard, ProductImage, PhoneArt, Loading, ErrorBox, Empty, Newsletter,
} from '../ui.js';

const HIGHLIGHT_LABELS = ['Display', 'Main camera', 'Battery', 'Charging', 'Processor'];

export function Home() {
  useEffect(() => setTitle(''), []);
  const { data, loading, error, reload } = useAsync(fetchPublished);
  const list = data || [];
  const featured = list.find((p) => p.featured) || list[0];
  const latest = list.slice(0, 3);

  const categories = [];
  for (const p of list) {
    if (!p.category) continue;
    let c = categories.find((x) => x.name === p.category);
    if (!c) { c = { name: p.category, count: 0, sample: p }; categories.push(c); }
    c.count += 1;
  }

  const highlights = featured
    ? specRows(featured).filter(([label]) => HIGHLIGHT_LABELS.includes(label)).slice(0, 4)
    : [];

  return html`
    <section class="hero">
      <div class="container hero-inner">
        <div class="hero-copy">
          <p class="eyebrow">AURA smartphones</p>
          <h1 class="h1">Bringing future to life.</h1>
          <p class="lead muted">Thoughtfully engineered phones with the display, camera and battery you actually use, in a design that stays out of the way.</p>
          <div class="hero-actions">
            <a class="btn" href="#/phones">Explore phones</a>
            <a class="link-arrow" href="#/compare">Compare models</a>
          </div>
        </div>
        <div class="hero-media">
          ${featured ? html`<${ProductImage} product=${featured} />` : html`<${PhoneArt} />`}
        </div>
      </div>
    </section>

    <section class="section" aria-labelledby="latest-h">
      <div class="container">
        <div class="section-head">
          <h2 id="latest-h" class="h2">The latest from AURA</h2>
          <a class="link-arrow" href="#/phones">All smartphones</a>
        </div>
        ${loading && html`<${Loading} label="Loading phones" />`}
        ${error && html`<${ErrorBox} error=${error} onRetry=${reload} title="We couldn’t load the phones" />`}
        ${!loading && !error && latest.length === 0 && html`
          <${Empty} title="New AURA phones are coming soon">Check back shortly.<//>`}
        ${latest.length > 0 && html`<div class="grid">${latest.map((p) => html`<${ProductCard} key=${p.id} p=${p} />`)}</div>`}
      </div>
    </section>

    ${featured && html`
      <section class="section section-soft" aria-labelledby="feat-h">
        <div class="container featured">
          <div class="featured-media"><${ProductImage} product=${featured} /></div>
          <div class="featured-copy">
            <p class="eyebrow">Featured</p>
            <h2 id="feat-h" class="h2">${featured.name}</h2>
            ${featured.tagline && html`<p class="lead muted">${featured.tagline}</p>`}
            ${highlights.length > 0 && html`
              <ul class="highlights">
                ${highlights.map(([label, value]) => html`<li><span>${label}</span><span>${value}</span></li>`)}
              </ul>`}
            <a class="btn" href=${`#/phones/${featured.slug}`}>Learn more</a>
          </div>
        </div>
      </section>`}

    ${categories.length > 0 && html`
      <section class="section" aria-labelledby="lineup-h">
        <div class="container">
          <div class="section-head"><h2 id="lineup-h" class="h2">Explore the AURA lineup</h2></div>
          <div class="lineup">
            ${categories.map((c) => html`
              <a class="lineup-item" key=${c.name} href=${`#/phones?cat=${encodeURIComponent(c.name)}`}>
                <div>
                  <h3>${c.name}</h3>
                  <p class="count">${c.count} ${c.count === 1 ? 'model' : 'models'}</p>
                </div>
                ${mainImage(c.sample)
                  ? html`<img src=${mainImage(c.sample)} alt="" loading="lazy" />`
                  : html`<${PhoneArt} />`}
              </a>`)}
          </div>
        </div>
      </section>`}

    <section class="section ${categories.length > 0 ? 'section-soft' : ''}" aria-labelledby="brand-h">
      <div class="container brand">
        <h2 id="brand-h" class="h2">Technology that earns its place.</h2>
        <div class="lead">
          <p>AURA designs smartphones around the things people touch every day: the screen, the camera, the battery. Everything else is kept simple and out of the way.</p>
          <p class="muted">Every model is documented with clear, complete specifications, so you can see exactly what you are choosing.</p>
        </div>
      </div>
    </section>

    <${Newsletter} />`;
}

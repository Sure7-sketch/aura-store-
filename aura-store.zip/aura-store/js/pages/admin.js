import {
  html, useState, useEffect, useAsync, supabase, BUCKET, useAdmin, go, errMsg,
  money, slugify, setTitle,
} from '../lib.js';
import { PhoneArt, Loading, ErrorBox } from '../ui.js';

/* NOTE ON SECURITY
   Nothing in this file is what protects the data. Every read and write below
   goes through Supabase Row Level Security (see supabase/schema.sql): even if
   someone edited this JavaScript in their browser, the database and storage
   would still reject any write that does not come from the admin account. */

/* ------------------------------------------------------------------ shell */

export function AdminApp({ path }) {
  useEffect(() => { document.title = 'Admin — AURA Store'; }, []);
  if (path === '/admin/login') return html`<${Login} />`;
  return html`<${AdminGate}><${AdminRoutes} path=${path} /><//>`;
}

function AdminGate({ children }) {
  const a = useAdmin();
  useEffect(() => { if (a.status === 'out') go('/admin/login'); }, [a.status]);

  if (a.status === 'loading' || a.status === 'out') {
    return html`<div class="login"><${Loading} label="Checking access" /></div>`;
  }
  if (a.status === 'error') {
    return html`<div class="login"><div class="login-card">
      <${ErrorBox} error=${a.error} title="Couldn’t verify admin access" />
    </div></div>`;
  }
  if (a.status === 'denied') {
    return html`
      <div class="login"><div class="login-card">
        <span class="logo">AURA</span>
        <p class="sub">This account is not authorised to manage the store.</p>
        <button class="btn btn-ghost" onClick=${() => supabase.auth.signOut().then(() => go('/admin/login'))}>Sign out</button>
        <p style="text-align:center;margin-top:20px;font-size:14px"><a class="link-arrow" href="#/">Back to the store</a></p>
      </div></div>`;
  }
  return html`<${AdminLayout} user=${a.user}>${children}<//>`;
}

function AdminLayout({ user, children }) {
  const path = (window.location.hash || '').replace(/^#/, '').split('?')[0];
  const cls = (to, exact) => ((exact ? path === to : path.startsWith(to)) ? 'active' : '');
  return html`
    <div class="admin">
      <header class="admin-bar">
        <div class="container">
          <div class="admin-nav">
            <a class="logo" href="#/admin" style="margin-right:16px;font-size:17px">AURA</a>
            <a class=${cls('/admin', true)} href="#/admin">Dashboard</a>
            <a class=${cls('/admin/products', false) && path !== '/admin/products/new' ? 'active' : ''} href="#/admin/products">Phones</a>
            <a class=${cls('/admin/products/new', true)} href="#/admin/products/new">Add phone</a>
          </div>
          <div class="admin-tools">
            <a href="#/" class="link-arrow">View store</a>
            <span>${user.email}</span>
            <button class="btn btn-ghost btn-sm"
              onClick=${() => supabase.auth.signOut().then(() => go('/admin/login'))}>Sign out</button>
          </div>
        </div>
      </header>
      <main class="admin-main"><div class="container">${children}</div></main>
    </div>`;
}

function AdminRoutes({ path }) {
  if (path === '/admin' || path === '/admin/') return html`<${Dashboard} />`;
  if (path === '/admin/products') return html`<${ProductList} />`;
  if (path === '/admin/products/new') return html`<${ProductForm} key="new" />`;
  if (path.startsWith('/admin/products/')) {
    const id = path.slice('/admin/products/'.length);
    return html`<${ProductForm} key=${id} id=${id} />`;
  }
  return html`<div class="state"><strong>Page not found</strong><a class="link-arrow" href="#/admin">Back to dashboard</a></div>`;
}

/* ------------------------------------------------------------------ login */

function Login() {
  const a = useAdmin();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => { if (a.status === 'ok') go('/admin'); }, [a.status]);

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true); setErr('');
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) {
      setErr(error.status === 400 ? 'Incorrect email or password.' : errMsg(error));
      setPassword('');
    }
    // On success useAdmin() sees the new session and redirects.
  }

  return html`
    <div class="login">
      <form class="login-card" onSubmit=${onSubmit}>
        <span class="logo">AURA</span>
        <p class="sub">Administrator sign in</p>
        ${err && html`<div class="alert error" role="alert">${err}</div>`}
        ${a.status === 'denied' && html`<div class="alert error" role="alert">This account is not authorised to manage the store.</div>`}
        <div class="field">
          <label for="a-email">Email</label>
          <input id="a-email" class="input" type="email" autocomplete="username" required value=${email}
            onInput=${(e) => setEmail(e.target.value)} />
        </div>
        <div class="field">
          <label for="a-pass">Password</label>
          <input id="a-pass" class="input" type="password" autocomplete="current-password" required value=${password}
            onInput=${(e) => setPassword(e.target.value)} />
        </div>
        <button class="btn" type="submit" disabled=${busy}>${busy ? 'Signing in…' : 'Sign in'}</button>
        <p style="text-align:center;margin-top:20px;font-size:14px"><a class="link-arrow" href="#/">Back to the store</a></p>
      </form>
    </div>`;
}

/* -------------------------------------------------------------- dashboard */

async function loadDashboard() {
  const [prods, subs, act] = await Promise.all([
    supabase.from('products').select('status'),
    supabase.from('subscribers').select('id', { count: 'exact', head: true }),
    supabase.from('activity_log').select('*').order('created_at', { ascending: false }).limit(10),
  ]);
  for (const r of [prods, subs, act]) if (r.error) throw r.error;
  const rows = prods.data || [];
  return {
    total: rows.length,
    published: rows.filter((r) => r.status === 'published').length,
    draft: rows.filter((r) => r.status === 'draft').length,
    subscribers: subs.count || 0,
    activity: act.data || [],
  };
}

function Dashboard() {
  useEffect(() => setTitle('Admin'), []);
  const { data, loading, error, reload } = useAsync(loadDashboard);
  return html`
    <div class="admin-head">
      <h1>Dashboard</h1>
      <a class="btn" href="#/admin/products/new">Add smartphone</a>
    </div>
    ${loading && html`<${Loading} />`}
    ${error && html`<${ErrorBox} error=${error} onRetry=${reload} />`}
    ${data && html`
      <div class="stats">
        <div class="stat"><div class="n">${data.total}</div><div class="l">Total products</div></div>
        <div class="stat"><div class="n">${data.published}</div><div class="l">Published</div></div>
        <div class="stat"><div class="n">${data.draft}</div><div class="l">Drafts</div></div>
        <div class="stat"><div class="n">${data.subscribers}</div><div class="l">Newsletter subscribers</div></div>
      </div>
      <section class="panel">
        <h2>Recent activity</h2>
        ${data.activity.length === 0
          ? html`<p class="muted">No activity yet. Add your first phone to get started.</p>`
          : html`<ul class="activity">${data.activity.map((a) => html`
              <li><span>${a.product_name} <span class="muted">was ${a.action}</span></span>
              <time>${new Date(a.created_at).toLocaleString()}</time></li>`)}</ul>`}
      </section>`}`;
}

/* ----------------------------------------------------------- product list */

function ProductList() {
  useEffect(() => setTitle('Admin — Phones'), []);
  const { data, loading, error, reload } = useAsync(async () => {
    const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data;
  });
  const [busyId, setBusyId] = useState(null);
  const [msg, setMsg] = useState(null);

  async function togglePublish(p) {
    setBusyId(p.id); setMsg(null);
    const next = p.status === 'published' ? 'draft' : 'published';
    const { error } = await supabase.from('products').update({ status: next }).eq('id', p.id);
    setBusyId(null);
    if (error) setMsg({ kind: 'error', text: errMsg(error) });
    else { setMsg({ kind: 'ok', text: `${p.name} is now ${next === 'published' ? 'published' : 'unpublished (draft)'}.` }); reload(); }
  }

  async function remove(p) {
    if (!window.confirm(`Delete “${p.name}” permanently? This cannot be undone.`)) return;
    setBusyId(p.id); setMsg(null);
    const { error } = await supabase.from('products').delete().eq('id', p.id);
    if (error) { setBusyId(null); setMsg({ kind: 'error', text: errMsg(error) }); return; }
    const paths = (p.images || []).map((i) => i.path).filter(Boolean);
    if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
    setBusyId(null);
    setMsg({ kind: 'ok', text: `${p.name} was deleted.` });
    reload();
  }

  return html`
    <div class="admin-head">
      <h1>Phones</h1>
      <a class="btn" href="#/admin/products/new">Add smartphone</a>
    </div>
    ${msg && html`<div class=${'alert ' + msg.kind} role="status">${msg.text}</div>`}
    ${loading && html`<${Loading} />`}
    ${error && html`<${ErrorBox} error=${error} onRetry=${reload} />`}
    ${data && data.length === 0 && html`
      <div class="panel state"><strong>No phones yet</strong>
        <a class="btn" href="#/admin/products/new" style="margin-top:8px">Add your first phone</a></div>`}
    ${data && data.length > 0 && html`
      <div class="panel tbl-wrap">
        <table class="tbl">
          <thead><tr><th></th><th>Name</th><th>Category</th><th>From</th><th>Status</th><th></th></tr></thead>
          <tbody>
            ${data.map((p) => html`
              <tr key=${p.id}>
                <td><div class="thumb-sm">${p.images && p.images[0] ? html`<img src=${p.images[0].url} alt="" />` : html`<${PhoneArt} />`}</div></td>
                <td><strong>${p.name}</strong>${p.featured && html` <span class="muted">· featured</span>`}</td>
                <td>${p.category || html`<span class="muted">—</span>`}</td>
                <td>${money(p.base_price)}</td>
                <td><span class=${'status ' + p.status}>${p.status === 'published' ? 'Published' : 'Draft'}</span></td>
                <td><div class="actions">
                  <a class="btn btn-ghost btn-sm" href=${`#/admin/products/${p.id}`}>Edit</a>
                  <button class="btn btn-ghost btn-sm" disabled=${busyId === p.id} onClick=${() => togglePublish(p)}>
                    ${p.status === 'published' ? 'Unpublish' : 'Publish'}</button>
                  <button class="btn btn-danger btn-sm" disabled=${busyId === p.id} onClick=${() => remove(p)}>Delete</button>
                </div></td>
              </tr>`)}
          </tbody>
        </table>
      </div>`}`;
}

/* ----------------------------------------------------------- product form */

const BLANK = {
  name: '', slug: '', category: '', tagline: '', description: '', base_price: '',
  status: 'draft', featured: false,
  images: [], colors: [], configurations: [],
  display: '', processor: '', main_camera: '', front_camera: '', battery: '', charging: '', os: '',
  extra_specs: [],
};

const MAX_BYTES = 5 * 1024 * 1024;
const TYPES = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };

function ProductForm({ id }) {
  const isNew = !id;
  const [productId] = useState(() => id || window.crypto.randomUUID());
  const [form, setForm] = useState(isNew ? BLANK : null);
  const [slugTouched, setSlugTouched] = useState(!isNew);
  const [removed, setRemoved] = useState([]); // storage paths to delete after a successful save
  const [uploading, setUploading] = useState(0);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState(null);

  const loaded = useAsync(async () => {
    if (isNew) return null;
    const { data, error } = await supabase.from('products').select('*').eq('id', id).maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('This phone could not be found.');
    return data;
  }, [id]);

  useEffect(() => {
    if (loaded.data) setForm({ ...BLANK, ...loaded.data, base_price: String(loaded.data.base_price ?? '') });
  }, [loaded.data]);

  useEffect(() => setTitle(isNew ? 'Admin — Add phone' : 'Admin — Edit phone'), [isNew]);

  if (!isNew && loaded.loading) return html`<${Loading} />`;
  if (!isNew && loaded.error) return html`<${ErrorBox} error=${loaded.error} onRetry=${loaded.reload} title="Couldn’t load this phone" />`;
  if (!form) return html`<${Loading} />`;

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setRow = (k, i, patch) => setForm((f) => ({ ...f, [k]: f[k].map((r, j) => (j === i ? { ...r, ...patch } : r)) }));
  const addRow = (k, row) => setForm((f) => ({ ...f, [k]: [...f[k], row] }));
  const delRow = (k, i) => setForm((f) => ({ ...f, [k]: f[k].filter((_, j) => j !== i) }));

  function onName(v) {
    setForm((f) => ({ ...f, name: v, slug: slugTouched ? f.slug : slugify(v) }));
  }

  async function onFiles(e) {
    const files = [...e.target.files];
    e.target.value = '';
    setMsg(null);
    for (const file of files) {
      const ext = TYPES[file.type];
      if (!ext) { setMsg({ kind: 'error', text: `“${file.name}” isn’t a PNG, JPG or WebP image.` }); continue; }
      if (file.size > MAX_BYTES) { setMsg({ kind: 'error', text: `“${file.name}” is larger than 5 MB.` }); continue; }
      setUploading((n) => n + 1);
      const path = `${productId}/${window.crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
        contentType: file.type, cacheControl: '31536000', upsert: false,
      });
      setUploading((n) => n - 1);
      if (error) { setMsg({ kind: 'error', text: `Upload failed for “${file.name}”: ${errMsg(error)}` }); continue; }
      const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
      setForm((f) => ({ ...f, images: [...f.images, { path, url: data.publicUrl }] }));
    }
  }

  function removeImage(i) {
    const im = form.images[i];
    if (im.path) setRemoved((r) => [...r, im.path]);
    delRow('images', i);
  }

  function makePrimary(i) {
    setForm((f) => ({ ...f, images: [f.images[i], ...f.images.filter((_, j) => j !== i)] }));
  }

  async function save(status) {
    setMsg(null);
    const name = form.name.trim();
    const slug = slugify(form.slug || name);
    const price = Number(form.base_price);
    if (!name) return setMsg({ kind: 'error', text: 'Enter the phone name.' });
    if (!slug) return setMsg({ kind: 'error', text: 'Enter a web address (slug) for this phone.' });
    if (form.base_price === '' || !Number.isFinite(price) || price < 0) {
      return setMsg({ kind: 'error', text: 'Enter a valid starting price.' });
    }
    if (uploading > 0) return setMsg({ kind: 'error', text: 'Please wait for image uploads to finish.' });

    const payload = {
      name, slug,
      category: form.category.trim(),
      tagline: form.tagline.trim(),
      description: form.description.trim(),
      base_price: price,
      status,
      featured: !!form.featured,
      images: form.images,
      colors: form.colors
        .filter((c) => (c.name || '').trim())
        .map((c) => ({ name: c.name.trim(), hex: c.hex || '#cccccc' })),
      configurations: form.configurations
        .filter((c) => (c.ram || '').trim() || (c.storage || '').trim())
        .map((c) => ({
          ram: (c.ram || '').trim(),
          storage: (c.storage || '').trim(),
          price: c.price === '' || c.price == null ? null : Number(c.price),
        })),
      display: form.display.trim(),
      processor: form.processor.trim(),
      main_camera: form.main_camera.trim(),
      front_camera: form.front_camera.trim(),
      battery: form.battery.trim(),
      charging: form.charging.trim(),
      os: form.os.trim(),
      extra_specs: form.extra_specs
        .filter((e) => (e.label || '').trim() && (e.value || '').trim())
        .map((e) => ({ label: e.label.trim(), value: e.value.trim() })),
    };
    if (payload.configurations.some((c) => c.price != null && (!Number.isFinite(c.price) || c.price < 0))) {
      return setMsg({ kind: 'error', text: 'A configuration has an invalid price.' });
    }

    setSaving(true);
    const q = isNew
      ? supabase.from('products').insert({ id: productId, ...payload })
      : supabase.from('products').update(payload).eq('id', productId);
    const { error } = await q;
    setSaving(false);

    if (error) {
      setMsg({
        kind: 'error',
        text: error.code === '23505'
          ? 'Another phone already uses this web address. Change the slug and try again.'
          : errMsg(error),
      });
      return;
    }

    if (removed.length) {
      await supabase.storage.from(BUCKET).remove(removed);
      setRemoved([]);
    }
    setForm((f) => ({ ...f, status, slug, base_price: String(price) }));
    setSlugTouched(true);
    setMsg({ kind: 'ok', text: status === 'published' ? 'Saved and published. It is live on the store.' : 'Saved as a draft. It is not visible on the store.' });
    if (isNew) go(`/admin/products/${productId}`);
  }

  async function remove() {
    if (!window.confirm(`Delete “${form.name}” permanently? This cannot be undone.`)) return;
    setSaving(true);
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (error) { setSaving(false); return setMsg({ kind: 'error', text: errMsg(error) }); }
    const paths = [...form.images.map((i) => i.path), ...removed].filter(Boolean);
    if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
    go('/admin/products');
  }

  const text = (k, label, props = {}) => html`
    <div class=${'field' + (props.full ? ' full' : '')}>
      <label for=${'f-' + k}>${label}</label>
      <input id=${'f-' + k} class="input" value=${form[k]} placeholder=${props.placeholder || ''}
        onInput=${(e) => set(k, e.target.value)} />
    </div>`;

  return html`
    <div class="admin-head">
      <h1>${isNew ? 'Add smartphone' : 'Edit smartphone'}</h1>
      ${!isNew && form.status === 'published' && html`<a class="link-arrow" href=${`#/phones/${form.slug}`}>View on store</a>`}
    </div>

    ${msg && html`<div class=${'alert ' + msg.kind} role=${msg.kind === 'error' ? 'alert' : 'status'}>${msg.text}</div>`}

    <section class="panel">
      <h2>Basics</h2>
      <div class="form-grid">
        <div class="field">
          <label for="f-name">Phone name</label>
          <input id="f-name" class="input" value=${form.name} placeholder="e.g. AURA X1 Pro" onInput=${(e) => onName(e.target.value)} />
        </div>
        ${text('category', 'Model category', { placeholder: 'e.g. Flagship, Mid-range' })}
        <div class="field">
          <label for="f-slug">Web address (slug)</label>
          <input id="f-slug" class="input" value=${form.slug} onInput=${(e) => { setSlugTouched(true); set('slug', e.target.value); }} />
          <p class="hint">Appears in the page link. Letters, numbers and hyphens.</p>
        </div>
        <div class="field">
          <label for="f-price">Starting price (${money(0).replace(/[\d.,\s]/g, '') || ''})</label>
          <input id="f-price" class="input" type="number" min="0" step="0.01" inputmode="decimal" value=${form.base_price}
            onInput=${(e) => set('base_price', e.target.value)} />
          <p class="hint">Used for the base model. Memory options can set their own price below.</p>
        </div>
        <div class="field full">
          <label for="f-tagline">Short description</label>
          <input id="f-tagline" class="input" maxlength="240" value=${form.tagline} placeholder="One line shown on product cards"
            onInput=${(e) => set('tagline', e.target.value)} />
        </div>
        <div class="field full">
          <label for="f-desc">Product description</label>
          <textarea id="f-desc" class="textarea" value=${form.description} onInput=${(e) => set('description', e.target.value)}></textarea>
        </div>
        <label class="check full">
          <input type="checkbox" checked=${form.featured} onChange=${(e) => set('featured', e.target.checked)} />
          Feature this phone on the homepage
        </label>
      </div>
    </section>

    <section class="panel">
      <h2>Images</h2>
      <p class="muted" style="font-size:14px;margin-bottom:16px">Upload your own AURA renders (PNG, JPG or WebP, up to 5 MB each). The first image is the main image. Transparent PNGs work best.</p>
      <div class="images">
        ${form.images.map((im, i) => html`
          <div class="img-tile" key=${im.path || im.url}>
            <div class="pic"><img src=${im.url} alt=${`Image ${i + 1}`} /></div>
            ${i === 0 ? html`<span class="tag">Main image</span>` : ''}
            <div class="row">
              ${i > 0 && html`<button type="button" class="mini" onClick=${() => makePrimary(i)}>Make main</button>`}
              <button type="button" class="mini danger" onClick=${() => removeImage(i)}>Remove</button>
            </div>
          </div>`)}
        <label class="upload-drop">
          <input type="file" accept="image/png,image/jpeg,image/webp" multiple class="sr-only" onChange=${onFiles} />
          ${uploading > 0 ? `Uploading ${uploading}…` : 'Upload images'}
        </label>
      </div>
      <p class="hint" style="margin-top:10px;font-size:12px;color:var(--muted)">To replace an image, remove it and upload the new one, then save.</p>
    </section>

    <section class="panel">
      <h2>Colours</h2>
      <div class="repeat">
        ${form.colors.map((c, i) => html`
          <div class="repeat-row colors" key=${i}>
            <input class="input" placeholder="Colour name" aria-label="Colour name" value=${c.name} onInput=${(e) => setRow('colors', i, { name: e.target.value })} />
            <input type="color" aria-label="Colour swatch" value=${c.hex || '#cccccc'} onInput=${(e) => setRow('colors', i, { hex: e.target.value })} />
            <button type="button" class="btn btn-ghost btn-sm" onClick=${() => delRow('colors', i)}>Remove</button>
          </div>`)}
        <div><button type="button" class="btn btn-ghost btn-sm" onClick=${() => addRow('colors', { name: '', hex: '#1b1b1f' })}>Add colour</button></div>
      </div>
    </section>

    <section class="panel">
      <h2>RAM and storage</h2>
      <p class="muted" style="font-size:14px;margin-bottom:16px">Each row is one option customers can choose. Leave the price empty to use the starting price.</p>
      <div class="repeat">
        ${form.configurations.map((c, i) => html`
          <div class="repeat-row configs" key=${i}>
            <input class="input" placeholder="RAM (e.g. 8 GB)" aria-label="RAM" value=${c.ram} onInput=${(e) => setRow('configurations', i, { ram: e.target.value })} />
            <input class="input" placeholder="Storage (e.g. 256 GB)" aria-label="Storage" value=${c.storage} onInput=${(e) => setRow('configurations', i, { storage: e.target.value })} />
            <input class="input" type="number" min="0" step="0.01" placeholder="Price" aria-label="Price" value=${c.price ?? ''} onInput=${(e) => setRow('configurations', i, { price: e.target.value })} />
            <button type="button" class="btn btn-ghost btn-sm" onClick=${() => delRow('configurations', i)}>Remove</button>
          </div>`)}
        <div><button type="button" class="btn btn-ghost btn-sm" onClick=${() => addRow('configurations', { ram: '', storage: '', price: '' })}>Add option</button></div>
      </div>
    </section>

    <section class="panel">
      <h2>Specifications</h2>
      <p class="muted" style="font-size:14px;margin-bottom:16px">Only the fields you fill in are shown on the website.</p>
      <div class="form-grid">
        ${text('display', 'Display', { placeholder: 'e.g. 6.7" AMOLED, 120 Hz' })}
        ${text('processor', 'Processor')}
        ${text('main_camera', 'Main camera')}
        ${text('front_camera', 'Front camera')}
        ${text('battery', 'Battery')}
        ${text('charging', 'Charging speed')}
        ${text('os', 'Operating system')}
      </div>
      <h2 style="margin-top:32px">Additional specifications</h2>
      <div class="repeat">
        ${form.extra_specs.map((e, i) => html`
          <div class="repeat-row extras" key=${i}>
            <input class="input" placeholder="Label (e.g. Water resistance)" aria-label="Label" value=${e.label} onInput=${(ev) => setRow('extra_specs', i, { label: ev.target.value })} />
            <input class="input" placeholder="Value (e.g. IP68)" aria-label="Value" value=${e.value} onInput=${(ev) => setRow('extra_specs', i, { value: ev.target.value })} />
            <button type="button" class="btn btn-ghost btn-sm" onClick=${() => delRow('extra_specs', i)}>Remove</button>
          </div>`)}
        <div><button type="button" class="btn btn-ghost btn-sm" onClick=${() => addRow('extra_specs', { label: '', value: '' })}>Add specification</button></div>
      </div>
    </section>

    <div class="sticky-actions">
      <div class="container">
        <button class="btn" disabled=${saving || uploading > 0} onClick=${() => save('published')}>
          ${saving ? 'Saving…' : form.status === 'published' ? 'Save changes' : 'Publish'}
        </button>
        <button class="btn btn-ghost" disabled=${saving || uploading > 0} onClick=${() => save('draft')}>
          ${form.status === 'published' ? 'Save and unpublish' : 'Save as draft'}
        </button>
        <span class=${'status ' + form.status}>${form.status === 'published' ? 'Published' : 'Draft'}</span>
        <span style="flex:1"></span>
        ${!isNew && html`<button class="btn btn-danger" disabled=${saving} onClick=${remove}>Delete phone</button>`}
        <a class="btn btn-ghost" href="#/admin/products">Back to list</a>
      </div>
    </div>`;
}

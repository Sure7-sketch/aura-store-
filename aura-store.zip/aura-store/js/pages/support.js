import { html, useEffect, setTitle, CONFIG } from '../lib.js';

const FAQ = [
  ['How do I choose between AURA phones?',
    'Open the Compare page, select up to four models and review their specifications side by side. Every product page also lists the full specifications for that model.'],
  ['Are the specifications on this website accurate?',
    'Specifications shown for each phone are the details published by AURA for that model. If something you need is not listed, contact support before you decide.'],
  ['Which colours and memory options are available?',
    'Each product page lists the colours and memory and storage configurations offered for that phone, with the price of each configuration.'],
  ['What happens to the phones I add to my bag?',
    'Your bag is stored on your own device. Online payment is not available on this store yet, so orders cannot be placed here.'],
  ['What does the warranty cover?',
    'See the warranty section on this page for what is and is not covered.'],
  ['How can I contact support?',
    'Use the contact details on this page. Please include your phone model and a short description of the issue.'],
];

export function Support() {
  useEffect(() => setTitle('Support'), []);
  const s = CONFIG.support || {};
  const contacts = [
    ['Email', s.email, s.email && `mailto:${s.email}`],
    ['Phone', s.phone, s.phone && `tel:${s.phone.replace(/[^+\d]/g, '')}`],
    ['Hours', s.hours, null],
    ['Address', s.address, null],
  ].filter(([, v]) => v);
  const months = CONFIG.warrantyMonths;

  return html`
    <div class="container">
      <div class="page-head">
        <h1 class="h1" style="font-size:clamp(38px,5vw,60px)">Support</h1>
        <p class="lead muted">Answers, warranty information and ways to reach us.</p>
      </div>

      <div class="support-grid">
        <section class="faq" aria-labelledby="faq-h">
          <h2 id="faq-h" class="h3" style="margin-bottom:20px">Frequently asked questions</h2>
          ${FAQ.map(([q, a]) => html`<details><summary>${q}</summary><p>${a}</p></details>`)}
        </section>

        <div>
          <section class="side-block" aria-labelledby="contact-h">
            <h3 id="contact-h">Customer support</h3>
            ${contacts.length > 0
              ? html`<dl>${contacts.map(([k, v, href]) => html`
                  <div><dt>${k}</dt><dd>${href ? html`<a href=${href}>${v}</a>` : v}</dd></div>`)}</dl>`
              : html`<p>Support contact details are being added. Please check back soon.</p>`}
          </section>

          <section class="side-block" aria-labelledby="warranty-h" id="warranty">
            <h3 id="warranty-h">Warranty</h3>
            <p>Every AURA smartphone comes with a ${months}-month limited warranty against manufacturing defects, starting from the date of purchase.</p>
            <ul>
              <li>Keep your proof of purchase. You will need it to make a claim.</li>
              <li>Accidental damage, liquid damage, misuse and unauthorised repairs are not covered.</li>
              <li>Batteries and accessories may have separate terms.</li>
            </ul>
          </section>
        </div>
      </div>
    </div>`;
}

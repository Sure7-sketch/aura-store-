import {
  html, useEffect, useMemo, useAsync, fetchPublished, setTitle, compareStore,
  toggleCompare, COMPARE_MAX, money, startingPrice, specRows, configLabel,
} from '../lib.js';
import { ProductImage, Loading, ErrorBox, Empty } from '../ui.js';

export function Compare() {
  useEffect(() => setTitle('Compare'), []);
  const { data, loading, error, reload } = useAsync(fetchPublished);
  const selectedIds = compareStore.use();
  const list = data || [];

  // Ignore ids of phones that have since been unpublished or deleted.
  const chosen = useMemo(
    () => selectedIds.map((id) => list.find((p) => p.id === id)).filter(Boolean),
    [data, selectedIds],
  );

  // One row per spec label that at least one selected phone actually has.
  const rows = useMemo(() => {
    const labels = [];
    const maps = chosen.map((p) => new Map(specRows(p)));
    for (const m of maps) for (const k of m.keys()) if (!labels.includes(k)) labels.push(k);
    return labels.map((label) => [label, maps.map((m) => m.get(label) || null)]);
  }, [chosen]);

  const memory = chosen.map((p) => (p.configurations || []).filter((c) => c && (c.ram || c.storage)).map(configLabel));
  const hasMemory = memory.some((m) => m.length > 0);
  const colors = chosen.map((p) => (p.colors || []).filter((c) => c && c.name).map((c) => c.name));
  const hasColors = colors.some((c) => c.length > 0);

  const Cell = ({ v }) => (v ? html`${v}` : html`<span class="dash" aria-label="Not specified">—</span>`);

  return html`
    <div class="container">
      <div class="page-head">
        <h1 class="h1" style="font-size:clamp(38px,5vw,60px)">Compare</h1>
        <p class="lead muted">Select up to ${COMPARE_MAX} phones to see their specifications side by side.</p>
      </div>

      ${loading && html`<${Loading} label="Loading phones" />`}
      ${error && html`<${ErrorBox} error=${error} onRetry=${reload} title="We couldn’t load the phones" />`}
      ${!loading && !error && list.length === 0 && html`<${Empty} title="No phones to compare yet">New AURA phones are coming soon.<//>`}

      ${list.length > 0 && html`
        <div class="picker" role="group" aria-label="Choose phones to compare">
          ${list.map((p) => {
            const on = selectedIds.includes(p.id);
            const full = !on && selectedIds.length >= COMPARE_MAX;
            return html`<button class=${'chip' + (on ? ' is-on' : '')} aria-pressed=${on} disabled=${full}
              onClick=${() => toggleCompare(p.id)}>${p.name}</button>`;
          })}
        </div>

        ${chosen.length < 2 && html`
          <${Empty} title=${chosen.length === 0 ? 'Choose two or more phones' : 'Choose at least one more phone'}>
            Pick from the list above to start comparing.
          <//>`}

        ${chosen.length >= 2 && html`
          <div class="table-wrap" style="padding-bottom:112px">
            <table class="cmp">
              <thead>
                <tr>
                  <th scope="col"><span class="sr-only">Specification</span></th>
                  ${chosen.map((p) => html`
                    <th scope="col">
                      <a class="cmp-img" href=${`#/phones/${p.slug}`}><${ProductImage} product=${p} /></a>
                      <a class="name" href=${`#/phones/${p.slug}`}>${p.name}</a>
                      <div class="muted" style="font-weight:400;font-size:14px">From ${money(startingPrice(p))}</div>
                      <button class="cmp-remove" onClick=${() => toggleCompare(p.id)}>Remove</button>
                    </th>`)}
                </tr>
              </thead>
              <tbody>
                ${hasColors && html`<tr><th scope="row">Colours</th>${colors.map((c) => html`<td><${Cell} v=${c.join(', ')} /></td>`)}</tr>`}
                ${hasMemory && html`<tr><th scope="row">Memory and storage</th>${memory.map((m) => html`<td>${m.length ? m.map((x) => html`<div>${x}</div>`) : html`<${Cell} v=${null} />`}</td>`)}</tr>`}
                ${rows.map(([label, values]) => html`
                  <tr><th scope="row">${label}</th>${values.map((v) => html`<td><${Cell} v=${v} /></td>`)}</tr>`)}
              </tbody>
            </table>
          </div>`}`}
    </div>`;
}

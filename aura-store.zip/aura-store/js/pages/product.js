import {
  html, useState, useEffect, useAsync, fetchBySlug, setTitle, money, configPrice,
  configLabel, specRows, addToCart, mainImage, compareStore, toggleCompare, COMPARE_MAX,
} from '../lib.js';
import { PhoneArt, Loading, ErrorBox } from '../ui.js';

export function ProductPage({ slug }) {
  const { data: p, loading, error, reload } = useAsync(() => fetchBySlug(slug), [slug]);
  const [img, setImg] = useState(0);
  const [ci, setCi] = useState(0);
  const [cfg, setCfg] = useState(0);
  const [added, setAdded] = useState(false);
  const selected = compareStore.use();

  useEffect(() => { setImg(0); setCi(0); setCfg(0); setAdded(false); }, [slug]);
  useEffect(() => { setTitle(p ? p.name : 'Smartphone'); }, [p]);

  if (loading) return html`<div class="container"><${Loading} label="Loading phone" /></div>`;
  if (error) return html`<div class="container"><${ErrorBox} error=${error} onRetry=${reload} title="We couldn’t load this phone" /></div>`;
  if (!p) {
    return html`
      <div class="container"><div class="state">
        <strong>This phone isn’t available</strong>
        <span>It may have been removed or isn’t published yet.</span>
        <a class="link-arrow" href="#/phones">Back to all smartphones</a>
      </div></div>`;
  }

  const images = Array.isArray(p.images) ? p.images : [];
  const colors = (p.colors || []).filter((c) => c && c.name);
  const configs = (p.configurations || []).filter((c) => c && (c.ram || c.storage));
  const config = configs[cfg];
  const price = config ? configPrice(p, config) : Number(p.base_price);
  const specs = specRows(p);
  const inCompare = selected.includes(p.id);
  const full = !inCompare && selected.length >= COMPARE_MAX;

  function onAdd() {
    addToCart({
      id: p.id,
      slug: p.slug,
      name: p.name,
      image: mainImage(p),
      color: colors[ci] ? colors[ci].name : '',
      ram: config ? config.ram || '' : '',
      storage: config ? config.storage || '' : '',
      price,
    });
    setAdded(true);
  }

  return html`
    <div class="container">
      <nav class="crumbs" aria-label="Breadcrumb">
        <a href="#/phones">Smartphones</a> / <span>${p.name}</span>
      </nav>

      <div class="product">
        <div>
          <div class="gallery-main">
            ${images[img] ? html`<img src=${images[img].url} alt=${`${p.name}, image ${img + 1}`} />` : html`<${PhoneArt} />`}
          </div>
          ${images.length > 1 && html`
            <div class="thumbs">
              ${images.map((im, i) => html`
                <button class=${'thumb' + (i === img ? ' is-on' : '')} onClick=${() => setImg(i)}
                  aria-label=${`Show image ${i + 1}`} aria-current=${i === img}>
                  <img src=${im.url} alt="" loading="lazy" />
                </button>`)}
            </div>`}
        </div>

        <div class="buy">
          ${p.category && html`<p class="eyebrow">${p.category}</p>`}
          <h1>${p.name}</h1>
          ${p.tagline && html`<p class="lead muted">${p.tagline}</p>`}

          <p class="price-lg">${money(price)}</p>

          ${colors.length > 0 && html`
            <div class="opt">
              <p class="opt-label">Colour <span>${colors[ci] ? colors[ci].name : ''}</span></p>
              <div class="swatches" role="radiogroup" aria-label="Colour">
                ${colors.map((c, i) => html`
                  <button class=${'swatch' + (i === ci ? ' is-on' : '')} role="radio" aria-checked=${i === ci}
                    aria-label=${c.name} title=${c.name} style=${`background:${c.hex || '#ccc'}`}
                    onClick=${() => { setCi(i); setAdded(false); }}></button>`)}
              </div>
            </div>`}

          ${configs.length > 0 && html`
            <div class="opt">
              <p class="opt-label">Memory and storage</p>
              <div class="configs" role="radiogroup" aria-label="Memory and storage">
                ${configs.map((c, i) => html`
                  <button class=${'config' + (i === cfg ? ' is-on' : '')} role="radio" aria-checked=${i === cfg}
                    onClick=${() => { setCfg(i); setAdded(false); }}>
                    <span>${configLabel(c)}</span><small>${money(configPrice(p, c))}</small>
                  </button>`)}
              </div>
            </div>`}

          <div class="hero-actions">
            <button class="btn" onClick=${onAdd}>Add to bag</button>
            <button class=${'btn btn-ghost' + (inCompare ? ' is-on' : '')} disabled=${full}
              onClick=${() => toggleCompare(p.id)} aria-pressed=${inCompare}>
              ${inCompare ? 'Remove from compare' : 'Add to compare'}
            </button>
          </div>
          <p class="added" role="status">${added && html`Added to your bag. <a href="#/cart">View bag</a>`}</p>

          ${p.description && html`<p class="desc">${p.description}</p>`}
        </div>
      </div>

      ${specs.length > 0 && html`
        <section class="specs" aria-labelledby="specs-h" style="border-top:1px solid var(--line)">
          <h2 id="specs-h" class="h2">Specifications</h2>
          <table class="spec-table">
            <tbody>
              ${specs.map(([label, value]) => html`<tr><th scope="row">${label}</th><td>${value}</td></tr>`)}
            </tbody>
          </table>
        </section>`}
    </div>`;
}

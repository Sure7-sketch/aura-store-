import {
  html, render, useState, useEffect, useRoute, go, isConfigured,
  cartStore,
} from './lib.js';
import { Home } from './pages/home.js';
import { Catalog } from './pages/catalog.js';
import { ProductPage } from './pages/product.js';
import { Compare } from './pages/compare.js';
import { Cart } from './pages/cart.js';
import { Support } from './pages/support.js';
import { AdminApp } from './pages/admin.js';

const Icon = {
  search: html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>`,
  bag: html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8V6.5a3 3 0 016 0V8" stroke-linecap="round"/></svg>`,
  menu: html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M4 8h16M4 16h16"/></svg>`,
  close: html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>`,
};

const LINKS = [
  ['/', 'Home'],
  ['/phones', 'Smartphones'],
  ['/compare', 'Compare'],
  ['/support', 'Support'],
];

function isActive(path, to) {
  if (to === '/') return path === '/';
  return path === to || path.startsWith(to + '/');
}

function Header({ path }) {
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [q, setQ] = useState('');
  const cart = cartStore.use();
  const count = cart.reduce((n, i) => n + i.qty, 0);

  useEffect(() => { setOpen(false); setSearching(false); }, [path]);

  function onSearch(e) {
    e.preventDefault();
    const term = q.trim();
    go(term ? `/phones?q=${encodeURIComponent(term)}` : '/phones');
    setSearching(false);
  }

  return html`
    <header class="site-header">
      <div class="container nav">
        <a class="logo" href="#/" aria-label="AURA — home">AURA</a>
        <ul class=${'nav-links' + (open ? ' open' : '')} id="primary-nav">
          ${LINKS.map(([to, label]) => html`
            <li><a href=${'#' + to} class=${isActive(path, to) ? 'active' : ''}>${label}</a></li>`)}
        </ul>
        <div class="nav-tools">
          <button class="icon-btn" aria-label="Search phones" aria-expanded=${searching}
            onClick=${() => setSearching((s) => !s)}>${Icon.search}</button>
          <a class="icon-btn" href="#/cart" aria-label=${`Shopping bag, ${count} item${count === 1 ? '' : 's'}`}>
            ${Icon.bag}${count > 0 && html`<span class="badge">${count}</span>`}
          </a>
          <button class="icon-btn nav-toggle" aria-label=${open ? 'Close menu' : 'Open menu'}
            aria-expanded=${open} aria-controls="primary-nav" onClick=${() => setOpen((o) => !o)}>
            ${open ? Icon.close : Icon.menu}
          </button>
        </div>
      </div>
      ${searching && html`
        <div class="search-panel">
          <div class="container">
            <form onSubmit=${onSearch} role="search">
              <label class="sr-only" for="site-search">Search smartphones</label>
              <input id="site-search" class="input" type="search" placeholder="Search AURA smartphones"
                autofocus value=${q} onInput=${(e) => setQ(e.target.value)} />
              <button class="btn" type="submit">Search</button>
            </form>
          </div>
        </div>`}
    </header>`;
}

function Footer() {
  return html`
    <footer class="site-footer">
      <div class="container">
        <div class="foot">
          <div>
            <a class="logo" href="#/">AURA</a>
            <p class="tag">The official online store for AURA smartphones.</p>
          </div>
          <div>
            <h4>Shop</h4>
            <ul>
              <li><a href="#/phones">All smartphones</a></li>
              <li><a href="#/compare">Compare phones</a></li>
              <li><a href="#/cart">Shopping bag</a></li>
            </ul>
          </div>
          <div>
            <h4>Support</h4>
            <ul>
              <li><a href="#/support">Help and FAQ</a></li>
              <li><a href="#/support">Warranty</a></li>
              <li><a href="#/support">Contact</a></li>
            </ul>
          </div>
        </div>
        <p class="legal">© ${new Date().getFullYear()} AURA. All rights reserved.</p>
      </div>
    </footer>`;
}

function Setup() {
  return html`
    <div class="setup">
      <p class="eyebrow">Setup required</p>
      <h1>Connect AURA Store to Supabase</h1>
      <p class="muted">The store reads its products from a Supabase project, which hasn’t been connected yet.</p>
      <ol>
        <li>Create a project at supabase.com.</li>
        <li>Run <code>supabase/schema.sql</code> in the SQL Editor.</li>
        <li>Put the project URL and anon key in <code>js/config.js</code>.</li>
        <li>Create your admin user and add it to the <code>admins</code> table (see README).</li>
      </ol>
    </div>`;
}

function NotFound() {
  return html`
    <div class="container"><div class="state">
      <strong>Page not found</strong>
      <a class="link-arrow" href="#/">Back to home</a>
    </div></div>`;
}

function PublicSite({ route }) {
  const { path, query } = route;
  let page;
  if (path === '/') page = html`<${Home} />`;
  else if (path === '/phones') page = html`<${Catalog} query=${query} />`;
  else if (path.startsWith('/phones/')) page = html`<${ProductPage} slug=${decodeURIComponent(path.slice(8))} />`;
  else if (path === '/compare') page = html`<${Compare} />`;
  else if (path === '/cart') page = html`<${Cart} />`;
  else if (path === '/support') page = html`<${Support} />`;
  else page = html`<${NotFound} />`;
  return html`
    <${Header} path=${path} />
    <main id="main">${page}</main>
    <${Footer} />`;
}

function App() {
  const route = useRoute();
  if (!isConfigured) return html`<${Setup} />`;
  if (route.path === '/admin' || route.path.startsWith('/admin/')) {
    return html`<${AdminApp} path=${route.path} />`;
  }
  return html`<${PublicSite} route=${route} />`;
}

render(html`<${App} />`, document.getElementById('app'));

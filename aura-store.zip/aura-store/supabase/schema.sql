-- AURA Store: database schema, Row Level Security and storage policies.
-- Run this whole file once in the Supabase SQL Editor (Dashboard -> SQL Editor).

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Admin allowlist
-- Only users listed here are administrators. The table has NO write policies,
-- so it can only be changed from the SQL editor / service role, never from the
-- website.
-- ---------------------------------------------------------------------------
create table if not exists public.admins (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admins enable row level security;

drop policy if exists "admins can read their own row" on public.admins;
create policy "admins can read their own row"
  on public.admins for select to authenticated
  using (user_id = auth.uid());

create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------------------------------------------------------------------------
-- Products
-- ---------------------------------------------------------------------------
create table if not exists public.products (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name           text not null check (char_length(name) between 1 and 120),
  category       text not null default '' check (char_length(category) <= 60),
  tagline        text not null default '' check (char_length(tagline) <= 240),
  description    text not null default '' check (char_length(description) <= 5000),
  base_price     numeric(10,2) not null check (base_price >= 0),
  status         text not null default 'draft' check (status in ('draft', 'published')),
  featured       boolean not null default false,

  -- [{ "path": "<storage path>", "url": "<public url>" }]  first item = main image
  images         jsonb not null default '[]'::jsonb check (jsonb_typeof(images) = 'array'),
  -- [{ "name": "Midnight", "hex": "#1b1b1f" }]
  colors         jsonb not null default '[]'::jsonb check (jsonb_typeof(colors) = 'array'),
  -- [{ "ram": "8 GB", "storage": "256 GB", "price": 599 }]  price optional
  configurations jsonb not null default '[]'::jsonb check (jsonb_typeof(configurations) = 'array'),

  display        text not null default '',
  processor      text not null default '',
  main_camera    text not null default '',
  front_camera   text not null default '',
  battery        text not null default '',
  charging       text not null default '',
  os             text not null default '',
  -- [{ "label": "Water resistance", "value": "IP68" }]
  extra_specs    jsonb not null default '[]'::jsonb check (jsonb_typeof(extra_specs) = 'array'),

  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create index if not exists products_status_created_idx on public.products (status, created_at desc);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists products_touch_updated_at on public.products;
create trigger products_touch_updated_at
  before update on public.products
  for each row execute function public.touch_updated_at();

alter table public.products enable row level security;

-- Visitors: read-only access to PUBLISHED phones. Admin: sees everything.
drop policy if exists "public can read published products" on public.products;
create policy "public can read published products"
  on public.products for select to anon, authenticated
  using (status = 'published' or public.is_admin());

drop policy if exists "admin can insert products" on public.products;
create policy "admin can insert products"
  on public.products for insert to authenticated
  with check (public.is_admin());

drop policy if exists "admin can update products" on public.products;
create policy "admin can update products"
  on public.products for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin can delete products" on public.products;
create policy "admin can delete products"
  on public.products for delete to authenticated
  using (public.is_admin());

-- ---------------------------------------------------------------------------
-- Activity log (written by a trigger, never by the browser)
-- ---------------------------------------------------------------------------
create table if not exists public.activity_log (
  id           bigint generated always as identity primary key,
  action       text not null,
  product_id   uuid,
  product_name text not null,
  created_at   timestamptz not null default now()
);
alter table public.activity_log enable row level security;

drop policy if exists "admin can read activity" on public.activity_log;
create policy "admin can read activity"
  on public.activity_log for select to authenticated
  using (public.is_admin());

create or replace function public.log_product_activity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.activity_log (action, product_id, product_name)
    values ('created', new.id, new.name);
    return new;
  elsif tg_op = 'UPDATE' then
    insert into public.activity_log (action, product_id, product_name)
    values (
      case
        when old.status <> new.status and new.status = 'published' then 'published'
        when old.status <> new.status then 'unpublished'
        else 'updated'
      end,
      new.id, new.name);
    return new;
  else
    insert into public.activity_log (action, product_id, product_name)
    values ('deleted', old.id, old.name);
    return old;
  end if;
end;
$$;

drop trigger if exists products_log_activity on public.products;
create trigger products_log_activity
  after insert or update or delete on public.products
  for each row execute function public.log_product_activity();

-- ---------------------------------------------------------------------------
-- Newsletter subscribers: anyone can subscribe, only the admin can read them.
-- ---------------------------------------------------------------------------
create table if not exists public.subscribers (
  id         bigint generated always as identity primary key,
  email      text not null unique
             check (char_length(email) <= 254 and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  created_at timestamptz not null default now()
);
alter table public.subscribers enable row level security;

drop policy if exists "anyone can subscribe" on public.subscribers;
create policy "anyone can subscribe"
  on public.subscribers for insert to anon, authenticated
  with check (true);

drop policy if exists "admin can read subscribers" on public.subscribers;
create policy "admin can read subscribers"
  on public.subscribers for select to authenticated
  using (public.is_admin());

drop policy if exists "admin can delete subscribers" on public.subscribers;
create policy "admin can delete subscribers"
  on public.subscribers for delete to authenticated
  using (public.is_admin());

-- ---------------------------------------------------------------------------
-- Storage: public bucket for product images, only the admin can write.
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880,
        array['image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "public can read product images" on storage.objects;
create policy "public can read product images"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'product-images');

drop policy if exists "admin can upload product images" on storage.objects;
create policy "admin can upload product images"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "admin can replace product images" on storage.objects;
create policy "admin can replace product images"
  on storage.objects for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin())
  with check (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "admin can delete product images" on storage.objects;
create policy "admin can delete product images"
  on storage.objects for delete to authenticated
  using (bucket_id = 'product-images' and public.is_admin());

-- ---------------------------------------------------------------------------
-- LAST STEP (run separately, after creating your admin user in
-- Authentication -> Users). Replace the email with your own:
--
--   insert into public.admins (user_id)
--   select id from auth.users where email = 'you@example.com';
-- ---------------------------------------------------------------------------
